The Molten Core Is Crafted At A MetalWork Station For: 12 Core
Fragment Ore, 6 Steel Bars, And 1 Scorched core