The Tank Engine Is Crafted At A MetalWork Station Costing:
4 Tank_Chips, 1 Molten Core, 18 Heavy Pipes, and 12 Steel Bars.
Has A 2% Chance to Drop From Penguin Tanks