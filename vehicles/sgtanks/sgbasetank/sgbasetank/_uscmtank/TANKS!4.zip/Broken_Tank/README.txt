The Broken Tank Can Be Found Outside U.S.C.M Bunkers And can Be "Harvested" for One
Tank Chip, Can Only Be Harvested Once, Is Destroyed If Mined