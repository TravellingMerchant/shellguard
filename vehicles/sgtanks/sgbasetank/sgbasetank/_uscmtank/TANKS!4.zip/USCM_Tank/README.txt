Costs: 1 Tank Engine, 14 Armored Plating, 1 Upgrade Module, 8 Wire, 2 Laser Diodes, 
12 Titanium Bars, And 1 USCM Sign. Crafted at MetalWork Station